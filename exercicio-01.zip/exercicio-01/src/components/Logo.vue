<template>
  <img src="../assets/logo.png" alt="Logo Vue">
</template>

<script>
export default {
  name: 'Logo',
}
</script>

<style scoped>
  img{
    width: 100px;
  }
 
</style>
